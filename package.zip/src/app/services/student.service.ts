import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {Gender} from "../entities/gender";
import {ApiConfig} from "../shared/api-config";
import {Student} from "../entities/student";

@Injectable({
  providedIn:'root'
})
export class StudentService{
  constructor(private http:HttpClient) {}

  async getAll():Promise<Student[]>{
    const url = ApiConfig.createUrl("students")
    // @ts-ignore
    return this.http.get<Student[]>(url).toPromise();
  }

  async searchAll(searchText: String): Promise<Student[]> {
    const url = ApiConfig.createUrl("student/" + searchText)
    // @ts-ignore

    return this.http.get<Student[]>(url).toPromise();
  }
}
