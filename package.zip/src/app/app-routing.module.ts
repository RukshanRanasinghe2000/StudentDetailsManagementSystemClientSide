import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
// import * as path from "path";
import {StudentTableComponent} from "./views/student-table/student-table.component";

const routes: Routes = [
  {path:'students',component:StudentTableComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
