import {Image} from "./Image";

export class Student {

  id?:Number;
  name?:String;
  indexNo?:String;
  dob?:String;
  address?:String;
  mobile?:String;
  email?:String;
  gender_id?:Number;
  image?:Image;

}
