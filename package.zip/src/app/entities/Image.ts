export class Image {
  id?:Number;
  image?:Blob;
}
