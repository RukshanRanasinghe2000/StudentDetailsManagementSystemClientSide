export class Gender {

  id?:Number;
  name?:String

}
