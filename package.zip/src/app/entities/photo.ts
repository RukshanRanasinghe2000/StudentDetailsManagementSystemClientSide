export class Photo {
  id?:Number;
  image?:Blob;
}
